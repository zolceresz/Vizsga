
function getCalc() {
    const szelesseg = parseFloat(document.getElementById("szelesseg").value);
    const magassag = parseFloat(document.getElementById("magassag").value);
    const tipus = parseFloat(document.getElementById("papirtipus").value);

    const terulet =Math.round((szelesseg*magassag)/1000)
    const koltseg = terulet*tipus

    document.getElementById("terulet").textContent = terulet;
    document.getElementById("koltseg").textContent = koltseg;

    if (szelesseg < 50 || magassag <50) {
            alert("Ellenőrizze az adatokat!")
    }

    if (koltseg > 500){
            document.getElementById("koltseg").style.backgroundColor="white";
            document.getElementById("koltseg").style.color="red";
            document.getElementById("koltseg").style.fontWeight="bold";
    }

    if (koltseg <= 500) {
            document.getElementById("koltseg").style.backgroundColor="white";
            document.getElementById("koltseg").style.color="green";
            document.getElementById("koltseg").style.fontWeight="bold";
    }
}
 